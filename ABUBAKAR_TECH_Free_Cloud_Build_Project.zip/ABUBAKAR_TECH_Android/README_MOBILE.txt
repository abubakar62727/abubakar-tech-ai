موبائل سے APK بنانے کے لیے:

AndroidIDE انسٹال کریں → Open Project → ABUBAKAR_TECH_Android منتخب کریں → Gradle Sync → Build APK.

اگر کوئی error آئے تو اس error کا screenshot بھیج دیں۔
