# ABUBAKAR TECH — Android Studio project

A proper Android Studio app project wrapping the ABUBAKAR TECH mobile UI in a native Android WebView. The HTML, CSS, JS, and branding image are bundled inside the APK, so the main app screen works from local app assets.

## Build
1. Install a recent Android Studio and Android SDK.
2. Open this folder as a project.
3. Let Gradle sync/download the Android Gradle Plugin and dependencies.
4. Make sure Android SDK Platform 35 is installed.
5. Run **Build > Build APK(s)**.
6. The debug APK will be under `app/build/outputs/apk/debug/`.

The project uses Android Gradle Plugin 9.4.0 / Gradle 9.6 and AndroidX WebKit 1.17.1. The app targets SDK 35 and has a minimum SDK of 23.

## Branding
- App name: ABUBAKAR TECH
- App icon/header logo: TECH AI branding image supplied in the conversation
- Main promotional image: the latest TECH AI banner supplied/generated for the app

## Links
External links such as WhatsApp are opened by the device browser/appropriate app instead of navigating away from the bundled app page.

## Security
The app only bundles the supplied information hub. The cybersecurity section is educational and defensive; it does not implement account takeover, password theft, crash/spam, or unauthorized access features.
